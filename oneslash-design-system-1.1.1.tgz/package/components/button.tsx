'use client';
import React, { useState, useEffect, useCallback } from 'react';

interface ButtonProps{
  size: 'small' | 'medium' | 'large';
  type: 'primary' | 'secondary' | 'tertiary' | 'textOnly';
  state: 'enabled' | 'hovered' | 'focused' | 'disabled';
  label: string;
  decoIcon?: string;
  actionIcon?: string;
  onClickButton?: any; 
  onClickActionIcon?: () => void;
}

type IconType = React.ComponentType<React.SVGProps<SVGSVGElement>>;

export default function Button({
  size,
  type,
  state,
  label,
  decoIcon,
  actionIcon,
  onClickButton,
  onClickActionIcon,
}: ButtonProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [IconLeft, setIconLeft] = useState<IconType | null>(null);
  const [IconRight, setIconRight] = useState<IconType | null>(null);

  // Import icon dynamically
  const loadIcon = useCallback(async (iconName?: string) => {
    if (!iconName) return null;
    try {
      const module = await import('@heroicons/react/24/outline');
      const Icon = module[iconName as keyof typeof module] as IconType;
      return Icon || null;
    } catch (error) {
      console.error(`Failed to load icon ${iconName}:`, error);
      return null;
    }
  }, []);

  useEffect(() => {
    const fetchIcons = async () => {
      if (decoIcon) {
        setIconLeft(await loadIcon(decoIcon));
      }
      if (actionIcon) {
        setIconRight(await loadIcon(actionIcon));
      }
    };
    fetchIcons();
  }, [decoIcon, actionIcon, loadIcon]);

  // Define classes for size
  const sizeClasses = {
    large: 'text-body1 p-2',
    medium: 'text-body1 p-1',
    small: 'text-body2 p-1',
  }[size];

  // Define icon size classes
  const sizeIcon = {
    large: 'w-6 h-6',
    medium: 'w-5 h-5',
    small: 'w-4 h-4',
  }[size];

  // Define classes for button types
  const baseTypeClasses = {
    primary: 'bg-light-accent-main dark:bg-dark-accent-main text-light-text-primary dark:text-dark-text-contrast',
    secondary: 'bg-light-primary-main dark:bg-dark-primary-main text-light-text-contrast dark:text-dark-text-contrast',
    tertiary: 'bg-light-background-accent200 dark:bg-dark-background-accent200 text-light-text-primary dark:text-dark-text-primary',
    textOnly: 'text-light-text-primary dark:text-dark-text-primary',
  }[type];

  const hoverTypeClasses = {
    primary: 'hover:bg-light-accent-dark hover:dark:bg-dark-accent-dark',
    secondary: 'hover:bg-light-primary-dark dark:hover:bg-dark-primary-dark',
    tertiary: 'hover:bg-light-background-accent300 hover:dark:bg-dark-background-accent300',
    textOnly: 'hover:bg-light-background-accent100 hover:dark:bg-dark-background-accent100',
  }[type];

  // State classes
  const stateClasses = {
    enabled: 'cursor-pointer',
    focused: 'ring-2 ring-offset-4 ring-offset-light-background-default dark:ring-offset-dark-background-default ring-light-accent-main dark:ring-dark-accent-main',
    disabled: type === 'textOnly'
      ? 'cursor-not-allowed text-light-text-disabled dark:text-dark-text-disabled bg-transparent'
      : 'cursor-not-allowed text-light-text-disabled dark:text-dark-text-disabled bg-light-actionBackground-disabled dark:bg-dark-actionBackground-disabled',
  };

  // Build the button classes dynamically
  const buttonClasses = `
    flex flex-row space-x-2 items-center rounded-[8px]
    ${sizeClasses}
    ${state === 'enabled' ? baseTypeClasses : ''}
    ${state === 'focused' ? stateClasses.focused : ''}
    ${state === 'disabled' ? stateClasses.disabled : baseTypeClasses}
    ${state !== 'disabled' && isHovered ? hoverTypeClasses : ''}
    `;

  return (
    <button
      className={buttonClasses}
      onMouseEnter={() => { if (state !== 'disabled') setIsHovered(true); }}
      onMouseLeave={() => { if (state !== 'disabled') setIsHovered(false); }}
      onClick={onClickButton} // Button click action
    >
      {IconLeft && (
          <IconLeft className={sizeIcon} />
      )}
      <div className="whitespace-nowrap px-2">{label}</div>
      {IconRight && (
        <div onClick={onClickActionIcon} className="cursor-pointer">
          <IconRight className={sizeIcon} />
        </div>
      )}
    </button>
  );
}